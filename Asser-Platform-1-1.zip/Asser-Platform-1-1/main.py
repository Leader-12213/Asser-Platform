import os
import json
import time
import secrets
import asyncio
import logging
from pathlib import Path
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup, constants
)
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler,
    ConversationHandler, ContextTypes, filters, JobQueue
)

# ─── إعداد الملفات واللوجينج ────────────────────────────────────────────
DATA_DIR = Path(__file__).parent / "data"
USERS_FILE = DATA_DIR / "users.json"
PEND_WDR = DATA_DIR / "pending_withdrawals.json"
PEND_DEP = DATA_DIR / "pending_deposits.json"
ADMIN_LOG = DATA_DIR / "admin_log.json"
os.makedirs(DATA_DIR, exist_ok=True)

# إعداد اللوجينج
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    filename='bot.log'
)
logger = logging.getLogger(__name__)

# تعريف هوية الأدمن (يجب استبدالها بآيدي حسابك)
ADMIN_IDS = [7952226615]  # استبدل هذا الرقم بآيدي حسابك

# ─── دالة تحميل البيانات المحسنة ───────────────────────────────────────
def load_data(path: Path, default=None, ensure_list=False):
    if not path.exists():
        return default if default is not None else ([] if ensure_list else {})
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
            
            # إذا طلبنا التأكد من أن البيانات قائمة وكانت غير ذلك
            if ensure_list and not isinstance(data, list):
                logger.warning(f"File {path} is not a list, returning default")
                return default if default is not None else []
                
            return data
    except Exception as e:
        logger.error(f"Error loading {path}: {e}")
        return default if default is not None else ([] if ensure_list else {})

def save_data(path: Path, obj):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Error saving {path}: {e}")

# ─── ثوابت عامة ──────────────────────────────────────────────
TOKEN = os.getenv("BOT_TOKEN", "PUT-YOUR-TOKEN-HERE")

# تعريف الخطط الاستثمارية
PLANS = {
    "daily": {
        "label": "يومي",
        "duration": 40,  # أيام
        "monthly_profit": 5.0,  # %
        "daily_profit": 0.1667  # %
    },
    "weekly": {
        "label": "أسبوعي",
        "duration": 40,  # أيام
        "monthly_profit": 6.0,  # %
        "weekly_profit": 1.4  # %
    },
    "monthly": {
        "label": "شهري",
        "duration": 40,  # أيام
        "monthly_profit": 10.0  # %
    }
}

HARVEST_MIN_SECONDS = 24 * 60 * 60  # 24 ساعة

# أسعار تحويل العملات
CONVERSION_RATES = {
    ('AC', 'EGP'): 5.0,
    ('AC', 'USDT'): 0.10,
    ('EGP', 'AC'): 1/5.0,
    ('EGP', 'USDT'): 0.02,
    ('USDT', 'AC'): 10.0,
    ('USDT', 'EGP'): 50.0
}

CONTRACT_TEXT = """
... [نفس محتوى العقد السابق] ...
"""

# ─── حالات المحادثة ─────────────────────────────────────────────
(REG_NAME, REG_EMAIL, REG_PASS, REG_PHONE,
 DEP_CURR, DEP_NAME, DEP_PHONE, DEP_AMOUNT,
 WDR_CURR, WDR_AMT,
 TRANSFER_AMOUNT, TRANSFER_CURR, TRANSFER_TARGET,
 TRANSFER_TYPE, TRANSFER_CONVERT_CURR_SOURCE, TRANSFER_CONVERT_AMOUNT, 
 TRANSFER_CONVERT_CURR_TARGET, TRANSFER_USER_CURR, TRANSFER_USER_AMOUNT, 
 TRANSFER_USER_TARGET, PLAN_CHOOSE, PLAN_AMOUNT) = range(22)

# حالات لوحة الأدمن
(ADMIN_MAIN, ADMIN_BAN_USER, ADMIN_BAN_REASON, ADMIN_UNBAN_USER,
 ADMIN_EDIT_USER, ADMIN_EDIT_BALANCE, ADMIN_EDIT_FIELD, 
 ADMIN_BROADCAST, ADMIN_STATS, ADMIN_REQUESTS) = range(22, 32)

# ─── دوال التسجيل ─────────────────────────────────────────────
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    # التحقق من وجود رابط دعوة
    args = context.args
    inviter_id = None
    if args and args[0].startswith("invite_"):
        try:
            inviter_id = args[0].split("_")[1]
        except (IndexError, ValueError):
            pass

    if uid in users:
        await update.message.reply_text("مرحبًا بك مجددًا 👋\nاكتب /help للاطّلاع على الأوامر.")
        return ConversationHandler.END
    
    context.user_data.clear()
    
    # إذا كان هناك مدعٍ صالح، زيادة عدد فريق المدعو
    if inviter_id and inviter_id in users:
        users[inviter_id]["team_count"] = users[inviter_id].get("team_count", 0) + 1
        save_data(USERS_FILE, users)
        context.user_data["inviter_id"] = inviter_id
    
    await update.message.reply_text("👤 ما اسمك الكامل؟")
    
    # إرسال إشعار للأدمن عند تسجيل مستخدم جديد
    if ADMIN_IDS:
        for admin_id in ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=f"👤 تسجيل مستخدم جديد!\n\n"
                         f"🆔 UID: {uid}\n"
                         f"👤 الاسم: {update.message.text}\n"
                         f"📅 الوقت: {time.strftime('%Y-%m-%d %H:%M:%S')}"
                )
            except Exception as e:
                logger.error(f"فشل في إرسال إشعار الأدمن: {e}")
    
    return REG_NAME

async def reg_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["name"] = update.message.text.strip()
    await update.message.reply_text("📧 بريدك الإلكتروني:")
    return REG_EMAIL

async def reg_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["email"] = update.message.text.strip()
    await update.message.reply_text("🔒 اختر كلمة مرور:")
    return REG_PASS

async def reg_pass(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["password"] = update.message.text.strip()
    await update.message.reply_text("📱 رقم هاتفك (مع كود الدولة):")
    return REG_PHONE

async def reg_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    # إنشاء كود دعوة فريد
    invite_code = secrets.token_urlsafe(8)
    
    users[uid] = {
        "name": context.user_data["name"],
        "email": context.user_data["email"],
        "phone": update.message.text.strip(),
        "password": context.user_data["password"],
        "balance": {"AC": 0.0, "EGP": 0.0, "USDT": 0.0},
        "plans": [],  # إضافة حقل للخطط
        "accepted_terms": False,
        "acceptance_time": None,
        # حقول جديدة لنظام الفريق
        "team_count": 0,
        "invite_code": invite_code,
        "inviter_id": context.user_data.get("inviter_id", None),
        # حالة الحظر
        "banned": False,
        "ban_reason": "",
        "ban_time": None
    }
    
    save_data(USERS_FILE, users)
    await update.message.reply_text("✅ تم إنشاء حسابك! اكتب /terms لقراءة العقد.")
    return ConversationHandler.END

# ─── /team ─────────────────────────────────────────────────────
async def team_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    if uid not in users:
        await update.message.reply_text("❌ لست مسجَّلًا. استخدم /start أولًا.")
        return
    
    user = users[uid]
    bot_username = context.bot.username
    invite_link = f"https://t.me/{bot_username}?start=invite_{uid}"
    
    message = (
        "🔰 <b>فريقك</b>\n\n"
        f"👥 عدد الأعضاء: <b>{user.get('team_count', 0)}</b>\n"
        f"🔑 كود الدعوة: <code>{user.get('invite_code', '')}</code>\n"
        f"📥 رابط الدعوة: <code>{invite_link}</code>\n\n"
        "كلما دخل عضو جديد عن طريق الرابط، يزداد عدد فريقك!"
    )
    
    await update.message.reply_text(
        text=message,
        parse_mode=constants.ParseMode.HTML
    )

# ─── /profile ───────────────────────────────────────────────────
async def profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    if uid not in users:
        await update.message.reply_text("❌ لست مسجَّلًا. استخدم /start أولًا.")
        return
    
    user = users[uid]
    terms_status = "نعم ✅" if user["accepted_terms"] else "لا ❌"
    terms_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(user["acceptance_time"])) if user["acceptance_time"] else "N/A"
    
    # حالة الحظر
    ban_status = ""
    if user.get("banned", False):
        ban_status = f"\n\n🚫 <b>حساب محظور!</b>\n"
        ban_status += f"السبب: {user.get('ban_reason', 'غير محدد')}\n"
        ban_status += f"الوقت: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(user.get('ban_time', 0)))}"
    
    # معالجة الخطط
    active_plans = []
    now = time.time()
    
    for plan in user.get("plans", []):
        # حساب الأيام المتبقية
        elapsed_days = (now - plan["join_date"]) / (24 * 3600)
        remaining_days = max(0, plan["duration"] - elapsed_days)
        
        # معلومات الخطة
        plan_info = (
            f"  - {PLANS[plan['type']]['label']}: {plan['amount']:.2f} AC\n"
            f"    المتبقي: {remaining_days:.1f} أيام\n"
            f"    آخر صرف: {time.strftime('%Y-%m-%d', time.localtime(plan.get('last_payout', plan['join_date'])))}"
        )
        active_plans.append(plan_info)
    
    plans_text = "\n".join(active_plans) if active_plans else "لا توجد خطط نشطة"
    
    text = (
        f"👤 ملفّك الشخصي\n"
        f"الاسم: {user['name']}\n"
        f"الإيميل: {user['email']}\n"
        f"الهاتف: {user['phone']}\n"
        f"موافقة على العقد: {terms_status}\n"
        f"وقت الموافقة: {terms_time}\n\n"
        f"🔰 فريقك:\n"
        f"  - عدد الأعضاء: {user.get('team_count', 0)}\n"
        f"  - كود الدعوة: {user.get('invite_code', '')}\n\n"
        f"الرصيد:\n"
        f"  - AC: {user['balance']['AC']:.2f}\n"
        f"  - EGP: {user['balance']['EGP']:.2f}\n"
        f"  - USDT: {user['balance']['USDT']:.2f}\n\n"
        f"📈 الخطط النشطة:\n{plans_text}"
        f"{ban_status}"
    )
    await update.message.reply_text(text, parse_mode=constants.ParseMode.HTML)

# ─── /balance ───────────────────────────────────────────────────
async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    if uid not in users:
        await update.message.reply_text("❌ لست مسجَّلًا. استخدم /start أولًا.")
        return

    bal = users[uid]["balance"]  
    text = (  
        f"💰 أرصدتك الحالية:\n"  
        f"  - AC: {bal['AC']:.2f}\n"  
        f"  - EGP: {bal['EGP']:.2f}\n"  
        f"  - USDT: {bal['USDT']:.2f}"  
    )  
    await update.message.reply_text(text)

# ─── /invest (بديل لـ /buy) ───────────────────────────────────────
async def invest_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    # التحقق من الحظر
    if users.get(uid, {}).get("banned", False):
        reason = users[uid].get("ban_reason", "غير محدد")
        await update.message.reply_text(f"🚫 حسابك محظور!\nالسبب: {reason}")
        return ConversationHandler.END
    
    keyboard = [
        [InlineKeyboardButton("يومي (4% شهريًا)", callback_data="daily")],
        [InlineKeyboardButton("أسبوعي (6% شهريًا)", callback_data="weekly")],
        [InlineKeyboardButton("شهري (10% شهريًا)", callback_data="monthly")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "📊 اختر خطة الاستثمار:",
        reply_markup=reply_markup
    )
    return PLAN_CHOOSE

async def plan_chosen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    plan_type = query.data
    context.user_data["plan_type"] = plan_type
    
    # الحصول على تفاصيل الخطة
    plan = PLANS[plan_type]
    
    # حساب العائدات
    daily_profit = plan.get("daily_profit", 0)
    weekly_profit = plan.get("weekly_profit", 0)
    monthly_profit = plan["monthly_profit"]
    
    message = (
        f"📈 خطة {plan['label']}:\n"
        f"  - المدة: {plan['duration']} يوم\n"
        f"  - العائد الشهري: {monthly_profit}%\n"
    )
    
    if plan_type == "daily":
        message += f"  - العائد اليومي: {daily_profit:.4f}%\n"
    elif plan_type == "weekly":
        message += f"  - العائد الأسبوعي: {weekly_profit}%\n"
    
    message += "\n💵 الرجاء إدخال المبلغ الذي تريد استثماره (AC):"
    
    await query.edit_message_text(message)
    return PLAN_AMOUNT

async def plan_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    if uid not in users:
        await update.message.reply_text("❌ لست مسجلًا. استخدم /start أولًا.")
        return ConversationHandler.END

    try:
        amount = float(update.message.text.strip())
        if amount <= 0:
            raise ValueError
    except Exception:
        await update.message.reply_text("❌ أدخل رقمًا صحيحًا أكبر من صفر.")
        return PLAN_AMOUNT

    # التحقق من الرصيد
    if users[uid]["balance"]["AC"] < amount:
        await update.message.reply_text("❌ رصيد AC غير كافٍ.")
        return ConversationHandler.END

    plan_type = context.user_data["plan_type"]
    plan = PLANS[plan_type]
    
    # إنشاء الخطة
    new_plan = {
        "type": plan_type,
        "amount": amount,
        "join_date": int(time.time()),
        "duration": plan["duration"],
        "last_payout": int(time.time())  # تم تحديثه ليكون وقت الشراء
    }
    
    # خصم المبلغ من الرصيد
    users[uid]["balance"]["AC"] -= amount
    
    # إضافة الخطة للمستخدم
    if "plans" not in users[uid]:
        users[uid]["plans"] = []
    users[uid]["plans"].append(new_plan)
    
    save_data(USERS_FILE, users)
    
    await update.message.reply_text(
        f"✅ تم شراء خطة {plan['label']} بنجاح!\n"
        f"المبلغ: {amount:.2f} AC\n"
        f"ستبدأ في جني الأرباح بعد مرور الفترة المحددة."
    )
    return ConversationHandler.END

# ─── /deposit ───────────────────────────────────────────────────
async def dep_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    # التحقق من الحظر
    if users.get(uid, {}).get("banned", False):
        reason = users[uid].get("ban_reason", "غير محدد")
        await update.message.reply_text(f"🚫 حسابك محظور!\nالسبب: {reason}")
        return ConversationHandler.END
    
    kb = [
        [InlineKeyboardButton("🌵 AC", callback_data="AC")],
        [InlineKeyboardButton("💵 EGP", callback_data="EGP")],
        [InlineKeyboardButton("💲 USDT", callback_data="USDT")]
    ]
    await update.message.reply_text("اختر العملة:", reply_markup=InlineKeyboardMarkup(kb))
    return DEP_CURR

async def dep_curr(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data["curr"] = query.data

    if query.data == "EGP":  
        await query.edit_message_text("اكتب اسمك الثلاثي:")  
        return DEP_NAME  
    else:  
        await query.edit_message_text(f"💳 أرسل عنوان محفظتك {query.data}:")  
        return DEP_AMOUNT

async def dep_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["name"] = update.message.text.strip()
    await update.message.reply_text("📱 رقم هاتفك:")
    return DEP_PHONE

async def dep_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["phone"] = update.message.text.strip()
    await update.message.reply_text("💵 المبلغ الذي تريد إيداعه (EGP):")
    return DEP_AMOUNT

async def dep_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        amount = float(update.message.text.strip())
        if amount <= 0:
            raise ValueError
    except Exception:
        await update.message.reply_text("❌ أدخل رقمًا صحيحًا أكبر من صفر.")
        return DEP_AMOUNT

    pend = load_data(PEND_DEP, [], ensure_list=True)  
    curr = context.user_data["curr"]  
    req = {  
        "uid": str(update.effective_user.id),  # تحويل إلى نص
        "currency": curr,  
        "amount": amount,  
        "time": int(time.time()),
        "user_name": context.user_data.get("name", ""),
        "user_phone": context.user_data.get("phone", ""),
        "status": "pending"
    }  
      
    pend.append(req)  
    save_data(PEND_DEP, pend)  
    
    # إرسال إشعار للأدمن
    if ADMIN_IDS:
        user_info = f"👤: {req['user_name']}\n📱: {req['user_phone']}" if curr == "EGP" else ""
        for admin_id in ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=f"📥 طلب إيداع جديد!\n\n"
                         f"🆔 UID: {req['uid']}\n"
                         f"💰 العملة: {curr}\n"
                         f"💵 المبلغ: {amount}\n"
                         f"{user_info}\n"
                         f"📅 الوقت: {time.strftime('%Y-%m-%d %H:%M:%S')}"
                )
            except Exception as e:
                logger.error(f"فشل في إرسال إشعار الأدمن: {e}")
      
    if curr == "EGP":  
        await update.message.reply_text(  
            "حوِّل على *01227911081* (≥50 EGP)\nثم اضغط تم.",  
            parse_mode=constants.ParseMode.MARKDOWN,  
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("تم الإيداع ✅", callback_data="done_dep")]])  
        )  
    elif curr == "AC":  
        await update.message.reply_text(  
            "أرسل المبلغ إلى:\n`0xAC_WALLET_ADDRESS`\nثم اضغط تم.",  
            parse_mode=constants.ParseMode.MARKDOWN,  
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("تم الإيداع ✅", callback_data="done_dep")]])  
        )  
    else:  # USDT  
        await update.message.reply_text(  
            "أرسل المبلغ إلى:\n`0xUSDT_WALLET_ADDRESS`\nثم اضغط تم.",  
            parse_mode=constants.ParseMode.MARKDOWN,  
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("تم الإيداع ✅", callback_data="done_dep")]])  
        )  
    return ConversationHandler.END

async def dep_done(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer("سيُراجع طلبك.")
    await query.edit_message_text("⏳ جار المراجعة …")

# ─── /withdraw ───────────────────────────────────────────────────
async def wdr_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    # التحقق من الحظر
    if users.get(uid, {}).get("banned", False):
        reason = users[uid].get("ban_reason", "غير محدد")
        await update.message.reply_text(f"🚫 حسابك محظور!\nالسبب: {reason}")
        return ConversationHandler.END
    
    kb = [
        [InlineKeyboardButton("🌵 AC", callback_data="AC")],
        [InlineKeyboardButton("💵 EGP", callback_data="EGP")],
        [InlineKeyboardButton("💲 USDT", callback_data="USDT")]
    ]
    await update.message.reply_text("عملة السحب:", reply_markup=InlineKeyboardMarkup(kb))
    return WDR_CURR

async def wdr_curr(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data["wc"] = query.data
    await query.edit_message_text("💵 اكتب المبلغ:")
    return WDR_AMT

async def wdr_amt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        amt = float(update.message.text.strip())
        if amt <= 0:
            raise ValueError
    except Exception:
        await update.message.reply_text("❌ أدخل رقمًا صحيحًا أكبر من صفر.")
        return WDR_AMT

    uid = str(update.effective_user.id)  
    currency = context.user_data["wc"]  
    users = load_data(USERS_FILE, {})  
      
    if uid not in users:  
        await update.message.reply_text("❌ سجل أولًا باستخدام /start.")  
        return ConversationHandler.END  
          
    if users[uid]["balance"].get(currency, 0) < amt:  
        await update.message.reply_text(f"❌ رصيد {currency} غير كافٍ.")  
        return ConversationHandler.END  
          
    fee = round(amt * 0.02, 2)  
    net = amt - fee  
      
    users[uid]["balance"][currency] -= amt  
    save_data(USERS_FILE, users)  
      
    pend = load_data(PEND_WDR, [], ensure_list=True)  
    wdr_request = {  
        "uid": uid,  
        "currency": currency,  
        "amount": net,  # المبلغ الصافي بعد الرسوم
        "fee": fee,  
        "time": int(time.time()),
        "user_name": users[uid]["name"],
        "user_phone": users[uid]["phone"],
        "status": "pending"
    }  
    pend.append(wdr_request)  
    save_data(PEND_WDR, pend)  
    
    # إرسال إشعار للأدمن
    if ADMIN_IDS:
        for admin_id in ADMIN_IDS:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=f"📤 طلب سحب جديد!\n\n"
                         f"🆔 UID: {uid}\n"
                         f"👤: {wdr_request['user_name']}\n"
                         f"📱: {wdr_request['user_phone']}\n"
                         f"💰 العملة: {currency}\n"
                         f"💵 المبلغ: {net} (صافي بعد رسوم 2%)\n"
                         f"📅 الوقت: {time.strftime('%Y-%m-%d %H:%M:%S')}"
                )
            except Exception as e:
                logger.error(f"فشل في إرسال إشعار الأدمن: {e}")
      
    await update.message.reply_text(  
        f"✅ تم طلب السحب.\n"  
        f"المبلغ: {amt:.2f} {currency}\n"  
        f"صافي بعد الرسوم (2%): {net:.2f} {currency}"  
    )  
    return ConversationHandler.END

# ─── /transfer ──────────────────────────────────────────────────
async def transfer_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    # التحقق من الحظر
    if users.get(uid, {}).get("banned", False):
        reason = users[uid].get("ban_reason", "غير محدد")
        await update.message.reply_text(f"🚫 حسابك محظور!\nالسبب: {reason}")
        return ConversationHandler.END
    
    keyboard = [
        [InlineKeyboardButton("تحويل عملات 💱", callback_data="convert")],
        [InlineKeyboardButton("تحويل بين المستخدمين 👤", callback_data="user_transfer")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "📤 اختر نوع التحويل:",
        reply_markup=reply_markup
    )
    return TRANSFER_TYPE

async def transfer_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    choice = query.data
    
    if choice == "convert":
        # تحويل العملات
        keyboard = [
            [InlineKeyboardButton("AC", callback_data="AC")],
            [InlineKeyboardButton("EGP", callback_data="EGP")],
            [InlineKeyboardButton("USDT", callback_data="USDT")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "💱 اختر العملة المصدر:",
            reply_markup=reply_markup
        )
        return TRANSFER_CONVERT_CURR_SOURCE
        
    else:  # user_transfer
        # تحويل بين المستخدمين
        keyboard = [
            [InlineKeyboardButton("AC", callback_data="AC")],
            [InlineKeyboardButton("EGP", callback_data="EGP")],
            [InlineKeyboardButton("USDT", callback_data="USDT")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "👤 اختر العملة للتحويل:",
            reply_markup=reply_markup
        )
        return TRANSFER_USER_CURR

# --- تحويل العملات ---
async def transfer_convert_curr_source(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data['source_currency'] = query.data
    
    await query.edit_message_text(
        f"↗️ سيتم التحويل من <b>{query.data}</b>\n"
        "🔢 الرجاء إدخال المبلغ:"
    )
    return TRANSFER_CONVERT_AMOUNT

async def transfer_convert_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    amount = update.message.text
    try:
        amount = float(amount)
        context.user_data['convert_amount'] = amount
        
        keyboard = [
            [InlineKeyboardButton("AC", callback_data="AC")],
            [InlineKeyboardButton("EGP", callback_data="EGP")],
            [InlineKeyboardButton("USDT", callback_data="USDT")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            "💱 اختر العملة الهدف:",
            reply_markup=reply_markup
        )
        return TRANSFER_CONVERT_CURR_TARGET
        
    except ValueError:
        await update.message.reply_text("⚠️ رجاء أدخل رقم صحيح")
        return TRANSFER_CONVERT_AMOUNT

async def transfer_convert_curr_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    target_currency = query.data
    source_currency = context.user_data['source_currency']
    amount = context.user_data['convert_amount']
    
    # حساب المبلغ المحول
    conversion_key = (source_currency, target_currency)
    if conversion_key not in CONVERSION_RATES:
        await query.edit_message_text("❌ لا يوجد سعر تحويل لهذه العملات")
        return ConversationHandler.END
    
    converted_amount = amount * CONVERSION_RATES[conversion_key]
    
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    if uid not in users:
        await query.edit_message_text("❌ لست مسجلاً!")
        return ConversationHandler.END
    
    if users[uid]["balance"].get(source_currency, 0) < amount:
        await query.edit_message_text(f"❌ رصيد {source_currency} غير كافٍ")
        return ConversationHandler.END
    
    # تنفيذ التحويل
    users[uid]["balance"][source_currency] -= amount
    users[uid]["balance"][target_currency] += converted_amount
    save_data(USERS_FILE, users)
    
    await query.edit_message_text(
        f"✅ تم التحويل بنجاح!\n\n"
        f"▫️ المبلغ الأصلي: {amount} {source_currency}\n"
        f"▫️ العملة الهدف: {target_currency}\n"
        f"▫️ المبلغ المحول: {converted_amount:.2f} {target_currency}\n\n"
        f"رصيدك الحالي:\n"
        f"  - {source_currency}: {users[uid]['balance'][source_currency]:.2f}\n"
        f"  - {target_currency}: {users[uid]['balance'][target_currency]:.2f}"
    )
    return ConversationHandler.END

# --- تحويل المستخدمين ---
async def transfer_user_curr(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data['transfer_currency'] = query.data
    
    await query.edit_message_text(
        f"↗️ سيتم التحويل بعملة <b>{query.data}</b>\n"
        "🔢 الرجاء إدخال المبلغ:"
    )
    return TRANSFER_USER_AMOUNT

async def transfer_user_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    amount = update.message.text
    try:
        amount = float(amount)
        context.user_data['transfer_amount'] = amount
        
        await update.message.reply_text(
            "👤 الرجاء إدخال معرف المستلم (أو رقم هاتفه):"
        )
        return TRANSFER_USER_TARGET
        
    except ValueError:
        await update.message.reply_text("⚠️ رجاء أدخل رقم صحيح")
        return TRANSFER_USER_AMOUNT

async def transfer_user_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target = update.message.text.strip()
    currency = context.user_data['transfer_currency']
    amount = context.user_data['transfer_amount']
    
    uid = str(update.effective_user.id)
    users = load_data(USERS_FILE, {})
    
    if uid not in users:
        await update.message.reply_text("❌ لست مسجلاً!")
        return ConversationHandler.END
    
    # البحث عن المستلم
    receiver_id = None
    for user_id, user_data in users.items():
        if str(user_id) == target or user_data.get('phone') == target:
            receiver_id = user_id
            break
    
    if not receiver_id:
        await update.message.reply_text("❌ المستخدم غير موجود")
        return ConversationHandler.END
    
    if users[uid]["balance"].get(currency, 0) < amount:
        await update.message.reply_text(f"❌ رصيد {currency} غير كافٍ")
        return ConversationHandler.END
    
    # تنفيذ التحويل
    users[uid]["balance"][currency] -= amount
    users[receiver_id]["balance"][currency] += amount
    save_data(USERS_FILE, users)
    
    await update.message.reply_text(
        f"✅ تم التحويل بنجاح!\n\n"
        f"▫️ المبلغ: {amount} {currency}\n"
        f"▫️ المستلم: {users[receiver_id]['name']}\n\n"
        f"رصيدك الحالي:\n"
        f"  - {currency}: {users[uid]['balance'][currency]:.2f}"
    )
    return ConversationHandler.END

# ─── /terms (عرض العقد والموافقة) ──────────────────────────────
async def terms(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # إرسال العقد في أجزاء
    for i in range(0, len(CONTRACT_TEXT), 4096):
        part = CONTRACT_TEXT[i:i+4096]
        await update.message.reply_text(part)
        time.sleep(0.5)  # تجنب Flood limits

    kb = [[InlineKeyboardButton("موافــــق ✅", callback_data="accept_terms")]]  
    await update.message.reply_text("إذا كنت موافقًا اضغط الزر:", reply_markup=InlineKeyboardMarkup(kb))

async def accept_terms(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = str(query.from_user.id)
    users = load_data(USERS_FILE, {})
    
    if uid in users:
        users[uid]["accepted_terms"] = True
        users[uid]["acceptance_time"] = int(time.time())
        save_data(USERS_FILE, users)
        await query.edit_message_text("✅ تم التوقيع على العقد.")
    else:
        await query.edit_message_text("❌ يجب التسجيل أولاً!")

# ─── /help ──────────────────────────────────────────────────────
async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = (
        "📚 <b>قائمة الأوامر المتاحة:</b>\n\n"
        "/start - التسجيل\n"
        "/profile - بياناتك\n"
        "/balance - أرصدتك\n"
        "/invest - شراء خطة استثمارية\n"
        "/deposit - إيداع\n"
        "/withdraw - سحب\n"
        "/transfer - تحويل الأموال\n"
        "/team - عرض فريقك ورابط الدعوة\n"
        "/terms - عقد الاستخدام\n"
        "/help - تعليمات"
    )
    await update.message.reply_text(
        help_text,
        parse_mode=constants.ParseMode.HTML
    )

# ─── لوحة تحكم الأدمن ─────────────────────────────────────────────
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    # التحقق من صلاحيات الأدمن
    if user_id not in ADMIN_IDS:
        await update.message.reply_text("❌ ليس لديك صلاحيات الوصول لهذا الأمر.")
        return ConversationHandler.END
    
    keyboard = [
        [InlineKeyboardButton("👥 حظر/فك حظر مستخدم", callback_data="admin_ban")],
        [InlineKeyboardButton("💰 تعديل الأرصدة", callback_data="admin_edit")],
        [InlineKeyboardButton("📊 الإحصائيات", callback_data="admin_stats")],
        [InlineKeyboardButton("📋 الطلبات المعلقة", callback_data="admin_requests")],
        [InlineKeyboardButton("📨 إرسال إشعار عام", callback_data="admin_broadcast")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "👑 <b>لوحة تحكم الأدمن الرئيسي</b>\n\n"
        "اختر الإدارة التي تريدها:",
        reply_markup=reply_markup,
        parse_mode=constants.ParseMode.HTML
    )
    return ADMIN_MAIN

async def admin_main(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    choice = query.data
    
    if choice == "admin_ban":
        keyboard = [
            [InlineKeyboardButton("حظر مستخدم", callback_data="ban_user")],
            [InlineKeyboardButton("فك حظر مستخدم", callback_data="unban_user")],
            [InlineKeyboardButton("↩️ رجوع", callback_data="admin_back")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            "🔒 <b>إدارة الحظر وفك الحظر</b>\n\n"
            "اختر الإجراء المطلوب:",
            reply_markup=reply_markup,
            parse_mode=constants.ParseMode.HTML
        )
        return ADMIN_BAN_USER
    
    elif choice == "admin_edit":
        await query.edit_message_text(
            "👤 <b>تعديل بيانات المستخدم</b>\n\n"
            "أرسل معرف المستخدم (UID):",
            parse_mode=constants.ParseMode.HTML
        )
        return ADMIN_EDIT_USER
    
    elif choice == "admin_stats":
        return await show_admin_stats(update, context)
    
    elif choice == "admin_requests":
        return await show_pending_requests(update, context)
    
    elif choice == "admin_broadcast":
        await query.edit_message_text(
            "📨 <b>إرسال إشعار عام</b>\n\n"
            "أرسل الرسالة التي تريد إرسالها لجميع المستخدمين:",
            parse_mode=constants.ParseMode.HTML
        )
        return ADMIN_BROADCAST

async def admin_ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    choice = query.data
    
    if choice == "ban_user":
        await query.edit_message_text(
            "🔒 <b>حظر مستخدم</b>\n\n"
            "أرسل معرف المستخدم (UID) الذي تريد حظره:",
            parse_mode=constants.ParseMode.HTML
        )
        return ADMIN_BAN_REASON
    
    elif choice == "unban_user":
        await query.edit_message_text(
            "🔓 <b>فك حظر مستخدم</b>\n\n"
            "أرسل معرف المستخدم (UID) الذي تريد فك حظره:",
            parse_mode=constants.ParseMode.HTML
        )
        return ADMIN_UNBAN_USER
    
    elif choice == "admin_back":
        return await admin_panel(update, context)

async def admin_ban_reason(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.message.text.strip()
    users = load_data(USERS_FILE, {})
    
    if uid not in users:
        await update.message.reply_text("❌ المستخدم غير موجود!")
        return ADMIN_MAIN
    
    context.user_data["ban_uid"] = uid
    keyboard = [
        [InlineKeyboardButton("محتال", callback_data="reason_scam")],
        [InlineKeyboardButton("ضد قوانين المنصة", callback_data="reason_rules")],
        [InlineKeyboardButton("أسباب أخرى", callback_data="reason_other")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "📝 اختر سبب الحظر:",
        reply_markup=reply_markup
    )
    return ADMIN_BAN_REASON

async def admin_ban_reason_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    reason = query.data
    
    reasons = {
        "reason_scam": "محتال",
        "reason_rules": "ضد قوانين المنصة",
        "reason_other": "أسباب أخرى"
    }
    
    context.user_data["ban_reason"] = reasons[reason]
    
    if reason == "reason_other":
        await query.edit_message_text("✍️ اكتب سبب الحظر:")
        return ADMIN_BAN_REASON
    
    uid = context.user_data["ban_uid"]
    users = load_data(USERS_FILE, {})
    
    if uid in users:
        users[uid]["banned"] = True
        users[uid]["ban_reason"] = reasons[reason]
        users[uid]["ban_time"] = int(time.time())
        save_data(USERS_FILE, users)
        
        # إرسال إشعار للمستخدم
        try:
            await context.bot.send_message(
                chat_id=int(uid),
                text=f"🚫 <b>حسابك محظور!</b>\n\n"
                     f"السبب: {reasons[reason]}\n\n"
                     f"للاستفسار، تواصل مع الدعم."
            )
        except Exception as e:
            logger.error(f"فشل إرسال إشعار للمستخدم: {e}")
        
        await query.edit_message_text(f"✅ تم حظر المستخدم {uid} بنجاح!")
    else:
        await query.edit_message_text("❌ المستخدم غير موجود!")
    
    return ADMIN_MAIN

async def admin_ban_reason_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reason = update.message.text
    uid = context.user_data["ban_uid"]
    users = load_data(USERS_FILE, {})
    
    if uid in users:
        users[uid]["banned"] = True
        users[uid]["ban_reason"] = reason
        users[uid]["ban_time"] = int(time.time())
        save_data(USERS_FILE, users)
        
        # إرسال إشعار للمستخدم
        try:
            await context.bot.send_message(
                chat_id=int(uid),
                text=f"🚫 <b>حسابك محظور!</b>\n\n"
                     f"السبب: {reason}\n\n"
                     f"للاستفسار، تواصل مع الدعم."
            )
        except Exception as e:
            logger.error(f"فشل إرسال إشعار للمستخدم: {e}")
        
        await update.message.reply_text(f"✅ تم حظر المستخدم {uid} بنجاح!")
    else:
        await update.message.reply_text("❌ المستخدم غير موجود!")
    
    return ADMIN_MAIN

async def admin_unban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.message.text.strip()
    users = load_data(USERS_FILE, {})
    
    if uid in users:
        users[uid]["banned"] = False
        users[uid]["ban_reason"] = ""
        users[uid]["ban_time"] = None
        save_data(USERS_FILE, users)
        
        # إرسال إشعار للمستخدم
        try:
            await context.bot.send_message(
                chat_id=int(uid),
                text="🎉 تم فك حظر حسابك!\n\nيمكنك الآن استخدام البوت بشكل طبيعي."
            )
        except Exception as e:
            logger.error(f"فشل إرسال إشعار للمستخدم: {e}")
        
        await update.message.reply_text(f"✅ تم فك حظر المستخدم {uid} بنجاح!")
    else:
        await update.message.reply_text("❌ المستخدم غير موجود!")
    
    return ADMIN_MAIN

async def admin_edit_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.message.text.strip()
    users = load_data(USERS_FILE, {})
    
    if uid not in users:
        await update.message.reply_text("❌ المستخدم غير موجود!")
        return ADMIN_MAIN
    
    context.user_data["edit_uid"] = uid
    user = users[uid]
    
    # عرض معلومات المستخدم
    text = (
        f"👤 <b>بيانات المستخدم</b>\n\n"
        f"🆔 UID: {uid}\n"
        f"👤 الاسم: {user['name']}\n"
        f"📧 الإيميل: {user['email']}\n"
        f"📱 الهاتف: {user['phone']}\n"
        f"🔑 كلمة المرور: {user['password']}\n\n"
        f"💰 الأرصدة:\n"
        f"  - AC: {user['balance']['AC']}\n"
        f"  - EGP: {user['balance']['EGP']}\n"
        f"  - USDT: {user['balance']['USDT']}\n\n"
        f"اختر الحقل الذي تريد تعديله:"
    )
    
    keyboard = [
        [InlineKeyboardButton("الاسم", callback_data="edit_name")],
        [InlineKeyboardButton("الإيميل", callback_data="edit_email")],
        [InlineKeyboardButton("الهاتف", callback_data="edit_phone")],
        [InlineKeyboardButton("كلمة المرور", callback_data="edit_password")],
        [InlineKeyboardButton("رصيد AC", callback_data="edit_balance_AC")],
        [InlineKeyboardButton("رصيد EGP", callback_data="edit_balance_EGP")],
        [InlineKeyboardButton("رصيد USDT", callback_data="edit_balance_USDT")],
        [InlineKeyboardButton("↩️ رجوع", callback_data="admin_back")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode=constants.ParseMode.HTML)
    return ADMIN_EDIT_FIELD

async def admin_edit_field(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    choice = query.data
    
    if choice == "admin_back":
        return await admin_panel(update, context)
    
    context.user_data["edit_field"] = choice
    field_name = {
        "edit_name": "الاسم",
        "edit_email": "الإيميل",
        "edit_phone": "الهاتف",
        "edit_password": "كلمة المرور",
        "edit_balance_AC": "رصيد AC",
        "edit_balance_EGP": "رصيد EGP",
        "edit_balance_USDT": "رصيد USDT"
    }[choice]
    
    await query.edit_message_text(f"✍️ أرسل القيمة الجديدة لـ {field_name}:")
    return ADMIN_EDIT_FIELD

async def admin_save_edit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    new_value = update.message.text
    field = context.user_data["edit_field"]
    uid = context.user_data["edit_uid"]
    users = load_data(USERS_FILE, {})
    
    if uid not in users:
        await update.message.reply_text("❌ المستخدم غير موجود!")
        return ADMIN_MAIN
    
    # تحديد الحقل المراد تعديله
    if field == "edit_name":
        users[uid]["name"] = new_value
    elif field == "edit_email":
        users[uid]["email"] = new_value
    elif field == "edit_phone":
        users[uid]["phone"] = new_value
    elif field == "edit_password":
        users[uid]["password"] = new_value
    elif field == "edit_balance_AC":
        try:
            users[uid]["balance"]["AC"] = float(new_value)
        except ValueError:
            await update.message.reply_text("❌ يجب إدخال رقم صحيح!")
            return ADMIN_EDIT_FIELD
    elif field == "edit_balance_EGP":
        try:
            users[uid]["balance"]["EGP"] = float(new_value)
        except ValueError:
            await update.message.reply_text("❌ يجب إدخال رقم صحيح!")
            return ADMIN_EDIT_FIELD
    elif field == "edit_balance_USDT":
        try:
            users[uid]["balance"]["USDT"] = float(new_value)
        except ValueError:
            await update.message.reply_text("❌ يجب إدخال رقم صحيح!")
            return ADMIN_EDIT_FIELD
    
    save_data(USERS_FILE, users)
    await update.message.reply_text("✅ تم التعديل بنجاح!")
    return ADMIN_MAIN

# ─── دالة الإحصائيات المحسنة ────────────────────────────────────
async def show_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        users = load_data(USERS_FILE, {})
        pend_dep = load_data(PEND_DEP, [], ensure_list=True)
        pend_wdr = load_data(PEND_WDR, [], ensure_list=True)
        
        # تسجيل لفحص البيانات
        logger.info(f"Total users: {len(users)}")
        logger.info(f"Pending deposits: {len(pend_dep)}")
        logger.info(f"Pending withdrawals: {len(pend_wdr)}")
        
        # إحصائيات المستخدمين
        total_users = len(users)
        active_users = sum(1 for u in users.values() if isinstance(u, dict) and u.get("balance", {}).get("AC", 0) > 0)
        banned_users = sum(1 for u in users.values() if isinstance(u, dict) and u.get("banned", False))
        
        # إحصائيات الطلبات
        dep_stats = {"AC": 0.0, "EGP": 0.0, "USDT": 0.0}
        for dep in pend_dep:
            if isinstance(dep, dict) and dep.get("status") == "pending":
                curr = dep.get("currency", "")
                if curr in dep_stats:
                    dep_stats[curr] += float(dep.get("amount", 0))
        
        wdr_stats = {"AC": 0.0, "EGP": 0.0, "USDT": 0.0}
        for wdr in pend_wdr:
            if isinstance(wdr, dict) and wdr.get("status") == "pending":
                curr = wdr.get("currency", "")
                if curr in wdr_stats:
                    wdr_stats[curr] += float(wdr.get("amount", 0))
        
        text = (
            "📊 <b>إحصائيات النظام</b>\n\n"
            f"👥 <b>المستخدمون:</b>\n"
            f"  - الإجمالي: {total_users}\n"
            f"  - النشطون: {active_users}\n"
            f"  - المحظورون: {banned_users}\n\n"
            f"📥 <b>طلبات الإيداع المعلقة:</b>\n"
            f"  - AC: {dep_stats['AC']:.2f}\n"
            f"  - EGP: {dep_stats['EGP']:.2f}\n"
            f"  - USDT: {dep_stats['USDT']:.2f}\n\n"
            f"📤 <b>طلبات السحب المعلقة:</b>\n"
            f"  - AC: {wdr_stats['AC']:.2f}\n"
            f"  - EGP: {wdr_stats['EGP']:.2f}\n"
            f"  - USDT: {wdr_stats['USDT']:.2f}\n\n"
            f"🔄 <b>آخر تحديث:</b> {time.strftime('%Y-%m-%d %H:%M:%S')}"
        )
        
        await update.message.reply_text(text, parse_mode=constants.ParseMode.HTML)
        
    except Exception as e:
        logger.error(f"Error in show_admin_stats: {e}")
        await update.message.reply_text(f"⚠️ حدث خطأ في عرض الإحصائيات: {str(e)}")
    
    return ADMIN_MAIN

async def admin_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message.text
    users = load_data(USERS_FILE, {})
    success = 0
    failed = 0
    
    for uid in users:
        try:
            await context.bot.send_message(
                chat_id=int(uid),
                text=f"📢 <b>إشعار عام من الإدارة</b>\n\n{message}",
                parse_mode=constants.ParseMode.HTML
            )
            success += 1
        except Exception:
            failed += 1
        await asyncio.sleep(0.1)  # تجنب الضغط على الخادم
    
    await update.message.reply_text(
        f"✅ تم إرسال الإشعار بنجاح!\n\n"
        f"عدد المستلمين: {success}\n"
        f"عدد الفاشل: {failed}"
    )
    return ADMIN_MAIN

# ─── دالة عرض الطلبات المعلقة المحسنة ───────────────────────────────
async def show_pending_requests(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        pend_dep = load_data(PEND_DEP, [], ensure_list=True)
        pend_wdr = load_data(PEND_WDR, [], ensure_list=True)
        
        # تسجيل لفحص البيانات
        logger.info(f"Deposits: {pend_dep}")
        logger.info(f"Withdrawals: {pend_wdr}")
        
        all_requests = []
        for dep in pend_dep:
            if isinstance(dep, dict) and dep.get("status") == "pending":
                dep["type"] = "إيداع"
                all_requests.append(dep)
        
        for wdr in pend_wdr:
            if isinstance(wdr, dict) and wdr.get("status") == "pending":
                wdr["type"] = "سحب"
                all_requests.append(wdr)
        
        if not all_requests:
            await update.message.reply_text("⚠️ لا توجد طلبات معلقة حالياً.")
            return ADMIN_MAIN

        for req in all_requests:
            # تأكد من وجود جميع الحقول المطلوبة
            req.setdefault("user_name", "غير معروف")
            req.setdefault("user_phone", "غير معروف")
            req.setdefault("amount", 0)
            req.setdefault("currency", "")
            req.setdefault("uid", "")
            req.setdefault("time", 0)
            
            text = (
                f"📋 <b>طلب {req['type']}</b>\n\n"
                f"👤 المستخدم: {req['user_name']}\n"
                f"📞 الهاتف: {req['user_phone']}\n"
                f"💵 المبلغ: {req['amount']} {req['currency']}\n"
                f"🆔 المعرف: {req['uid']}\n"
                f"⏰ الوقت: {time.strftime('%Y-%m-%d %H:%M', time.localtime(req['time']))}\n"
            )
            
            keyboard = [
                [
                    InlineKeyboardButton("✅ موافقة", 
                        callback_data=f"approve_{req['type']}_{req['uid']}_{req['amount']}_{req['currency']}"),
                    InlineKeyboardButton("❌ رفض", 
                        callback_data=f"reject_{req['type']}_{req['uid']}_{req['amount']}_{req['currency']}")
                ]
            ]
            await update.message.reply_text(
                text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode=constants.ParseMode.HTML
            )
            
    except Exception as e:
        logger.error(f"Error in show_pending_requests: {e}")
        await update.message.reply_text(f"حدث خطأ: {str(e)}")
    
    return ADMIN_MAIN

# ─── دالة معالجة الطلبات المحسنة ─────────────────────────────────
async def handle_request_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    try:
        data = query.data.split("_")
        if len(data) != 5:  # تأكد من صحة البيانات
            await query.edit_message_text("⚠️ بيانات الطلب غير صالحة")
            return ADMIN_MAIN
            
        action, req_type, uid, amount, currency = data
        
        # تسجيل البيانات للفحص
        logger.info(f"Processing: {action}, {req_type}, {uid}, {amount}, {currency}")
        
        if req_type == "إيداع":
            pend_data = load_data(PEND_DEP, [], ensure_list=True)
            file_path = PEND_DEP
        else:
            pend_data = load_data(PEND_WDR, [], ensure_list=True)
            file_path = PEND_WDR
        
        users = load_data(USERS_FILE, {})
        
        # البحث عن الطلب وتحديثه
        updated = False
        for req in pend_data:
            if (str(req.get("uid")) == uid and 
                str(req.get("amount")) == amount and 
                req.get("currency") == currency):
                
                req["status"] = "approved" if action == "approve" else "rejected"
                updated = True
                break
                
        if not updated:
            await query.edit_message_text("⚠️ لم يتم العثور على الطلب")
            return ADMIN_MAIN
        
        # معالجة الرصيد
        if action == "approve":
            if req_type == "إيداع" and uid in users:
                users[uid]["balance"][currency] = users[uid]["balance"].get(currency, 0) + float(amount)
        else:
            if req_type == "سحب" and uid in users:
                # إعادة المبلغ للمستخدم في حالة رفض السحب
                users[uid]["balance"][currency] = users[uid]["balance"].get(currency, 0) + float(amount)
        
        # حفظ التغييرات
        save_data(file_path, pend_data)
        save_data(USERS_FILE, users)
        
        # إرسال إشعار للمستخدم
        try:
            await context.bot.send_message(
                chat_id=int(uid),
                text=f"📢 <b>تم {action} طلبك</b>\n\n"
                     f"النوع: {req_type}\n"
                     f"المبلغ: {amount} {currency}\n"
                     f"الحالة: {'مقبول' if action == 'approve' else 'مرفوض'}\n"
                     f"الوقت: {time.strftime('%Y-%m-%d %H:%M')}",
                parse_mode=constants.ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"فشل إرسال إشعار للمستخدم: {e}")
        
        await query.edit_message_text(f"✅ تم {action} الطلب بنجاح")
        
    except Exception as e:
        logger.error(f"Error in handle_request_action: {e}")
        await query.edit_message_text(f"⚠️ حدث خطأ: {str(e)}")
    
    return ADMIN_MAIN

# ─── دالة توزيع الأرباح اليومية المعدلة ─────────────────────────────
async def daily_payout(context: ContextTypes.DEFAULT_TYPE, manual=False):
    users = load_data(USERS_FILE, {})
    current_time = time.time()
    payout_count = 0
    max_backpay_days = 30  # الحد الأقصى للأيام المرتجعة للخطط اليومية
    
    for uid, user_data in users.items():
        if "plans" not in user_data:
            continue
            
        # إنشاء نسخة من القائمة لتجنب تغييرها أثناء التكرار
        plans = user_data["plans"][:]
        
        for plan in plans:
            # معالجة الخطة اليومية
            if plan["type"] == "daily":
                # إذا كان التوزيع يدويًا، تجاهل حساب الوقت ووزع الربح ليوم واحد فقط
                if manual:
                    # حساب الربح ليوم واحد
                    daily_profit = PLANS["daily"]["daily_profit"] / 100
                    profit = plan["amount"] * daily_profit
                    
                    # تحديث الرصيد
                    user_data["balance"]["AC"] += profit
                    
                    # تحديث وقت آخر صرف (الوقت الحالي)
                    plan["last_payout"] = current_time
                    
                    # إرسال إشعار للمستخدم
                    try:
                        await context.bot.send_message(
                            chat_id=int(uid),
                            text=f"📈 تم إضافة أرباح يومية يدويًا إلى رصيدك!\n\n"
                                 f"🪙 المبلغ: {profit:.4f} AC\n"
                                 f"📊 من خطة: {PLANS['daily']['label']}\n"
                                 f"💼 رأس المال: {plan['amount']} AC\n\n"
                                 f"رصيدك الجديد: {user_data['balance']['AC']:.2f} AC"
                        )
                        payout_count += 1
                    except Exception as e:
                        logger.error(f"فشل في إرسال الإشعار للمستخدم {uid}: {e}")
                else:
                    # معالجة الخطط القديمة (بدون last_payout)
                    if "last_payout" not in plan:
                        plan["last_payout"] = plan["join_date"]
                        
                    # حساب الأيام المنقضية منذ آخر صرف (بالثواني)
                    elapsed_time = current_time - plan["last_payout"]
                    
                    # حساب عدد الأيام الكاملة المنقضية
                    full_days_elapsed = int(elapsed_time // (24 * 3600))
                    
                    # تطبيق الحد الأقصى للأيام المرتجعة
                    if full_days_elapsed > max_backpay_days:
                        full_days_elapsed = max_backpay_days
                        
                    if full_days_elapsed >= 1:
                        # حساب الربح التراكمي لجميع الأيام المنقضية
                        daily_profit = PLANS["daily"]["daily_profit"] / 100
                        total_profit = plan["amount"] * daily_profit * full_days_elapsed
                        
                        # تحديث الرصيد
                        user_data["balance"]["AC"] += total_profit
                        
                        # تحديث وقت آخر صرف (الوقت الحالي)
                        plan["last_payout"] = current_time
                        
                        # إرسال إشعار للمستخدم
                        try:
                            await context.bot.send_message(
                                chat_id=int(uid),
                                text=f"📈 تم إضافة أرباح يومية تراكمية إلى رصيدك!\n\n"
                                     f"🪙 المبلغ الإجمالي: {total_profit:.4f} AC\n"
                                     f"📅 عدد الأيام: {full_days_elapsed} يوم\n"
                                     f"📊 من خطة: {PLANS['daily']['label']}\n"
                                     f"💼 رأس المال: {plan['amount']} AC\n\n"
                                     f"رصيدك الجديد: {user_data['balance']['AC']:.2f} AC"
                            )
                            payout_count += 1
                        except Exception as e:
                            logger.error(f"فشل في إرسال الإشعار للمستخدم {uid}: {e}")
            
            # معالجة الخطة الشهرية عند انتهاء المدة (لا تتأثر باليدوي)
            elif plan["type"] == "monthly":
                # حساب الأيام المنقضية منذ بداية الخطة
                elapsed_days = (current_time - plan["join_date"]) / (24 * 3600)
                
                # إذا انقضت مدة 40 يوم
                if elapsed_days >= 40:
                    # حساب الربح الكامل (10%)
                    profit = plan["amount"] * (PLANS["monthly"]["monthly_profit"] / 100)
                    
                    # إضافة رأس المال + الربح إلى رصيد المستخدم
                    total_payout = plan["amount"] + profit
                    user_data["balance"]["AC"] += total_payout
                    
                    # إزالة الخطة من قائمة خطط المستخدم
                    user_data["plans"].remove(plan)
                    
                    # إرسال إشعار للمستخدم
                    try:
                        await context.bot.send_message(
                            chat_id=int(uid),
                            text=f"🎉 تم اكتمال الخطة الشهرية بنجاح!\n\n"
                                 f"🪙 تم إضافة رأس المال والأرباح إلى رصيدك:\n"
                                 f"  - رأس المال: {plan['amount']} AC\n"
                                 f"  - الأرباح: {profit:.4f} AC (10%)\n"
                                 f"  - الإجمالي: {total_payout:.4f} AC\n\n"
                                 f"📅 مدة الخطة: 40 يوم\n\n"
                                 f"رصيدك الجديد: {user_data['balance']['AC']:.2f} AC"
                        )
                        payout_count += 1
                    except Exception as e:
                        logger.error(f"فشل في إرسال الإشعار للمستخدم {uid}: {e}")
    
    if payout_count > 0:
        save_data(USERS_FILE, users)
        logger.info(f"✅ تم توزيع الأرباح اليومية لـ {payout_count} خطة")
        return f"✅ تم توزيع الأرباح على {payout_count} مستخدم"
    else:
        return "⚠️ لا توجد خطط يومية تحتاج إلى توزيع أرباح"

# ─── أمر توزيع الأرباح يدويًا ──────────────────────────────────
async def manual_payout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ هذا الأمر متاح فقط للمشرفين")
        return

    keyboard = [
        [InlineKeyboardButton("✅ نعم، وزع الأرباح", callback_data="confirm_payout")],
        [InlineKeyboardButton("❌ إلغاء", callback_data="cancel_payout")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        "⚠️ هل أنت متأكد من توزيع الأرباح الآن؟",
        reply_markup=reply_markup
    )

async def confirm_payout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "confirm_payout":
        # إرسال رسالة بأن العملية جارية
        await query.edit_message_text("⏳ جاري توزيع الأرباح...")

        # استدعاء دالة التوزيع مع العلم أنها يدوية
        result = await daily_payout(context, manual=True)
        await query.edit_message_text(result)
    else:  # cancel_payout
        await query.edit_message_text("❌ تم إلغاء توزيع الأرباح.")

# ─── تسجيل Handlers ─────────────────────────────────────────────
def main():
    app = ApplicationBuilder().token(TOKEN).build()
    job_queue = app.job_queue

    # إضافة مهمة توزيع الأرباح اليومية (تعمل كل 24 ساعة)
    if job_queue:
        job_queue.run_repeating(
            daily_payout, 
            interval=24 * 3600,  # كل 24 ساعة
            first=10  # تبدأ بعد 10 ثواني من تشغيل البوت
        )

    # تسجيل مستخدم جديد  
    app.add_handler(ConversationHandler(  
        entry_points=[CommandHandler("start", start)],  
        states={  
            REG_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, reg_name)],  
            REG_EMAIL: [MessageHandler(filters.TEXT & ~filters.COMMAND, reg_email)],  
            REG_PASS: [MessageHandler(filters.TEXT & ~filters.COMMAND, reg_pass)],  
            REG_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, reg_phone)],  
        },  
        fallbacks=[]  
    ))  

    # استثمار في خطط (بديل لـ /buy)  
    app.add_handler(ConversationHandler(  
        entry_points=[CommandHandler("invest", invest_start)],  
        states={  
            PLAN_CHOOSE: [CallbackQueryHandler(plan_chosen)],  
            PLAN_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, plan_amount)],  
        },  
        fallbacks=[]  
    ))  

    # إيداع  
    app.add_handler(ConversationHandler(  
        entry_points=[CommandHandler("deposit", dep_start)],  
        states={  
            DEP_CURR: [CallbackQueryHandler(dep_curr)],  
            DEP_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, dep_name)],  
            DEP_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, dep_phone)],  
            DEP_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, dep_amount)],  
        },  
        fallbacks=[]  
    ))  

    # سحب  
    app.add_handler(ConversationHandler(  
        entry_points=[CommandHandler("withdraw", wdr_start)],  
        states={  
            WDR_CURR: [CallbackQueryHandler(wdr_curr)],  
            WDR_AMT: [MessageHandler(filters.TEXT & ~filters.COMMAND, wdr_amt)],  
        },  
        fallbacks=[]  
    ))  

    # تحويل
    app.add_handler(ConversationHandler(  
        entry_points=[CommandHandler("transfer", transfer_start)],  
        states={  
            TRANSFER_TYPE: [CallbackQueryHandler(transfer_type)], 
            # حالات تحويل العملات  
            TRANSFER_CONVERT_CURR_SOURCE: [CallbackQueryHandler(transfer_convert_curr_source)],  
            TRANSFER_CONVERT_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, transfer_convert_amount)],  
            TRANSFER_CONVERT_CURR_TARGET: [CallbackQueryHandler(transfer_convert_curr_target)],  
            # حالات تحويل المستخدمين  
            TRANSFER_USER_CURR: [CallbackQueryHandler(transfer_user_curr)],  
            TRANSFER_USER_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, transfer_user_amount)],  
            TRANSFER_USER_TARGET: [MessageHandler(filters.TEXT & ~filters.COMMAND, transfer_user_target)],  
        },  
        fallbacks=[]  
    ))
    
        # لوحة الأدمن
    app.add_handler(ConversationHandler(
        entry_points=[CommandHandler("admin", admin_panel)],
        states={
            ADMIN_MAIN: [CallbackQueryHandler(admin_main)],
            ADMIN_BAN_USER: [CallbackQueryHandler(admin_ban_user)],
            ADMIN_BAN_REASON: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_ban_reason),
                CallbackQueryHandler(admin_ban_reason_choice, pattern="^reason_")
            ],
            ADMIN_UNBAN_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_unban_user)],
            ADMIN_EDIT_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_edit_user)],
            ADMIN_EDIT_FIELD: [
                CallbackQueryHandler(admin_edit_field),
                MessageHandler(filters.TEXT & ~filters.COMMAND, admin_save_edit)
            ],
            ADMIN_STATS: [CallbackQueryHandler(show_admin_stats)],
            ADMIN_REQUESTS: [CallbackQueryHandler(show_pending_requests)],
            ADMIN_BROADCAST: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_broadcast)]
        },
        fallbacks=[CallbackQueryHandler(admin_panel, pattern="^admin_back$")]
    ))

    # معالجات الأزرار  
    app.add_handler(CallbackQueryHandler(dep_done, pattern="^done_dep$"))  
    app.add_handler(CallbackQueryHandler(accept_terms, pattern="^accept_terms$"))  
    app.add_handler(CallbackQueryHandler(handle_request_action, pattern="^approve_"))  
    app.add_handler(CallbackQueryHandler(handle_request_action, pattern="^reject_"))  

    # أوامر أخرى  
    app.add_handler(CommandHandler("profile", profile))  
    app.add_handler(CommandHandler("balance", balance))  
    app.add_handler(CommandHandler("terms", terms))  
    app.add_handler(CommandHandler("help", help_cmd))  
    app.add_handler(CommandHandler("team", team_command)) 
    
    # أمر توزيع الأرباح يدويًا
    app.add_handler(CommandHandler("payout", manual_payout))
    app.add_handler(CallbackQueryHandler(confirm_payout, pattern="^(confirm_payout|cancel_payout)$"))

    # ─── بدء تشغيل البوت ───────────────────────────────────────────  
    logger.info("✅ البوت يعمل بنجاح...")  
    app.run_polling()

if __name__ == "__main__":
    main()